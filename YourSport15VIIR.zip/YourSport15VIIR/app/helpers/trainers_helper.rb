module TrainersHelper
end
