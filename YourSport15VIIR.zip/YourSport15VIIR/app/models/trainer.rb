class Trainer < ApplicationRecord
  belongs_to :department
  has_many :courses, dependent: :destroy
end
