class Place < ApplicationRecord
  has_many :departments, dependent: :destroy
end
