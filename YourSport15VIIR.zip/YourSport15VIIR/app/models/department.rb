class Department < ApplicationRecord
  has_many :trainers, dependent: :destroy
  has_many :courses, dependent: :destroy


 belongs_to :place


  validates :tipo_deporte, presence: true,
                      numericality: {less_than_or_equal_to: 4},
                      length: { is: 1 }

end
