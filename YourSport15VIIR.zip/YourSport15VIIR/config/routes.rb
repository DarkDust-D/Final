Rails.application.routes.draw do
  resources :places
  resources :students
  resources :courses
  resources :departments
  resources :trainers
  devise_for :users
  get 'welcome/index'
  get 'departments/getAllTrainers'
  get 'departments/getAllCourses'
  get 'departments/getTrainerDepartment'
  get 'courses/getAllMatriculaCourses'
  get 'students/enrollments'

  root 'welcome#index'
end
